# ⏤͟͞⚡𝘼𝘿𝘼 ✘𝙎𝙏𝙍𝙀𝘼𝙈˼⃝࿐🫧

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<p>A Smooth Music Bot. It Can Play Music In Your Group And Channel</p>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<a href="https://t.me/shhyrr" class="btn-flip" data-back="EVID" data-front="JOIN TELIGRAM">TELIGRAM JOIN</a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### Overview Section
This Python-based bot, utilizing Pyrogram and Py-Tgcalls, enables effortless streaming of songs, videos, and live streams directly into group calls from various sources.

### Key Features

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

1. **Source Variety:**
   - Stream content from YouTube, Soundcloud, Apple Music, Spotify, Resso, Live Streams, and Telegram Audios & Videos.

2. **Stability and Reliability:**
   - Developed from scratch to ensure stability and minimize crashes, featuring attractive thumbnails for a better user experience.

3. **Advanced Controls:**
   - Enjoy advanced controls such as Loop, Seek, Shuffle, Specific Skip, Playlists, and more for a customized listening experience.

4. **Multi-Language Support:**
   - Supports multiple languages, enhancing accessibility and user-friendliness for a diverse user base.
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
### Get Started
Enhance your group chat experience with seamless music and video streaming.
 Visit the 

 <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
 
# [⏤͟͞⚡𝘼𝘿𝘼 ✘𝙎𝙏𝙍𝙀𝘼𝙈˼⃝࿐🫧 ](https://t.me/shhyrr) on Telegram today!

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">





## Deploy On Heroku


<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/Evidclue/2025"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

## 🏷 Support Section
**_[Updates](https://t.me/shhyrr)_**

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

**_[Py-tgcalls](https://github.com/pytgcalls)_** 

**_[Pyrogram](https://github.com/pyrogram)_**
